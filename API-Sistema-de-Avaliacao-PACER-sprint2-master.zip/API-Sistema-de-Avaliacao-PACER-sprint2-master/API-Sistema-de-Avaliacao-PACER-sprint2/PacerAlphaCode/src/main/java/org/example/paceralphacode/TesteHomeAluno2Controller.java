package org.example.paceralphacode;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class TesteHomeAluno2Controller implements TesteHomeAlunoController {

    @FXML
    private AnchorPane HomeAluno2;

    @FXML
    private ImageView logofatec2;

    @FXML
    private Label textpacer2;

    @Override
    public void start(Stage primaryStage) {
        TableView<Person> tableView = new TableView<>();

        TableColumn<Person, String> nameColumn = new TableColumn<>("Nome");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Person, Integer> ageColumn = new TableColumn<>("Idade");
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));

        tableView.getColumns().add(nameColumn);
        tableView.getColumns().add(ageColumn);

        List<Person> people = new ArrayList<>();
        people.add(new Person("João", 25));
        people.add(new Person("Maria", 30));
        tableView.getItems().addAll(people);

        nameColumn.prefWidthProperty().bind(tableView.widthProperty().divide(2));
        ageColumn.prefWidthProperty().bind(tableView.widthProperty().divide(2));

        VBox vbox = new VBox(tableView);
        Scene scene = new Scene(vbox);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Exemplo de TableView");
        primaryStage.show();
    }
}




