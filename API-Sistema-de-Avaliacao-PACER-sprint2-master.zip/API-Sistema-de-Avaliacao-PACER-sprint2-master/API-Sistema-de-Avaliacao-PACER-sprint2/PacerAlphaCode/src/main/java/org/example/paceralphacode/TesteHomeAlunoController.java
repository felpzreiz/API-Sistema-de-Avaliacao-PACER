package org.example.paceralphacode;

import javafx.stage.Stage;

public interface TesteHomeAlunoController {
    void start(Stage primaryStage);
}
