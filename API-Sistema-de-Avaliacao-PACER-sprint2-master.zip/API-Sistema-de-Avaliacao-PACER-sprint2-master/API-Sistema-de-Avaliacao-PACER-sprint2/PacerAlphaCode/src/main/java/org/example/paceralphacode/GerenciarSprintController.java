package org.example.paceralphacode;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class GerenciarSprintController {

    @FXML
    private ImageView fatec;

    @FXML
    private AnchorPane gSprints;

}
